#!/bin/bash

echo "Program for Q3 starts"
python Q3.py