#!/bin/bash

echo "Program for Q7 starts"
python Q7.py