#!/bin/bash

echo "Program for Q4 part(a) starts"
python Q4.1.py