#!/bin/bash

echo "Program for Q2 starts"
python Q2.py