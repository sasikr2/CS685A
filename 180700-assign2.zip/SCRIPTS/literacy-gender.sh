#!/bin/bash

echo "Program for Q9 starts"
python Q9.py