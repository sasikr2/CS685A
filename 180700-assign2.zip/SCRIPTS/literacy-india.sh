#!/bin/bash

echo "Program for Q6 starts"
python Q6.py