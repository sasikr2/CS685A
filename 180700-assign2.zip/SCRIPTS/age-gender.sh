#!/bin/bash

echo "Program for Q8 starts"
python Q8.py