#!/bin/bash

echo "Program for Q1 starts"
python Q1.py