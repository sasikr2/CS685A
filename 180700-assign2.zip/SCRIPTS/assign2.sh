#!/bin/bash

./percent-india.sh
./gender-india.sh
./geography-india.sh
./3-to-2-ratio.sh
./2-to-1-ratio.sh
./age-india.sh
./literacy-india.sh
./region-india.sh
./age-gender.sh
./literacy-gender.sh