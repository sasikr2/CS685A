#!/bin/bash

echo "Program for Q4 part(b) starts"
python Q4.2.py