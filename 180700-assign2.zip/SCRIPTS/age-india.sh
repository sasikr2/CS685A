#!/bin/bash

echo "Program for Q5 starts"
python Q5.py